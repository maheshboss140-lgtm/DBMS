-- ReelBook DBMS project — sample MySQL queries
-- Table names and columns correspond to drizzle/schema.ts.

-- 1. Find screenings for a date, with cinema and auditorium names.
SELECT m.title,
       c.name AS cinema,
       a.name AS screen,
       st.startsAt,
       st.format,
       st.basePrice
FROM showtimes AS st
JOIN movies AS m ON m.id = st.movieId
JOIN auditoriums AS a ON a.id = st.auditoriumId
JOIN cinemas AS c ON c.id = a.cinemaId
WHERE DATE(st.startsAt) = '2026-11-01'
ORDER BY st.startsAt;

-- 2. Read every seat for a showtime and mark existing reservations.
SELECT s.rowLabel,
       s.seatNumber,
       s.seatType,
       CASE WHEN bs.id IS NULL THEN 'available' ELSE 'booked' END AS seatStatus
FROM seats AS s
LEFT JOIN bookingSeats AS bs
  ON bs.seatId = s.id AND bs.showtimeId = 42
WHERE s.auditoriumId = 101
ORDER BY s.rowLabel, s.seatNumber;

-- 3. Reserve a set of seats atomically from application code.
-- The app validates the requested seats and groups booking writes in one
-- transaction; the composite unique index handles concurrent reservations.
START TRANSACTION;
SELECT id FROM seats
WHERE id IN (101001, 101002) AND auditoriumId = 101
INSERT INTO bookings (reference, customerId, showtimeId, totalAmount, status)
VALUES ('RB-7A2D19CF', 15, 42, 560.00, 'confirmed');
INSERT INTO bookingSeats (bookingId, showtimeId, seatId, price)
VALUES (88, 42, 101001, 280.00), (88, 42, 101002, 280.00);
COMMIT;

-- 4. Inspect the composite unique index that is the final double-booking guard.
-- It is declared once in drizzle/schema.ts and the checked-in migration.
SHOW INDEX FROM bookingSeats
WHERE Key_name = 'booking_seats_showtime_seat_unique';

-- 5. Retrieve ticket history and its seat labels for one customer.
SELECT b.reference,
       m.title,
       st.startsAt,
       b.totalAmount,
       GROUP_CONCAT(CONCAT(s.rowLabel, s.seatNumber)
                    ORDER BY s.rowLabel, s.seatNumber) AS seatLabels
FROM bookings AS b
JOIN showtimes AS st ON st.id = b.showtimeId
JOIN movies AS m ON m.id = st.movieId
JOIN bookingSeats AS bs ON bs.bookingId = b.id
JOIN seats AS s ON s.id = bs.seatId
WHERE b.customerId = 15
GROUP BY b.id, b.reference, m.title, st.startsAt, b.totalAmount
ORDER BY b.createdAt DESC;
