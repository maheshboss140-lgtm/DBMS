import {
  date,
  datetime,
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Starter account table retained for compatibility with the supplied project. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const cinemas = mysqlTable(
  "cinemas",
  {
    id: int("id").autoincrement().primaryKey(),
    slug: varchar("slug", { length: 80 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    neighborhood: varchar("neighborhood", { length: 120 }).notNull(),
    address: varchar("address", { length: 240 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ slugUnique: uniqueIndex("cinemas_slug_unique").on(table.slug) })
);

export const auditoriums = mysqlTable(
  "auditoriums",
  {
    id: int("id").autoincrement().primaryKey(),
    cinemaId: int("cinemaId")
      .notNull()
      .references(() => cinemas.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 80 }).notNull(),
    screenType: varchar("screenType", { length: 40 })
      .default("Standard")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ cinemaIdx: index("auditoriums_cinema_idx").on(table.cinemaId) })
);

export const seats = mysqlTable(
  "seats",
  {
    id: int("id").autoincrement().primaryKey(),
    auditoriumId: int("auditoriumId")
      .notNull()
      .references(() => auditoriums.id, { onDelete: "cascade" }),
    rowLabel: varchar("rowLabel", { length: 3 }).notNull(),
    seatNumber: int("seatNumber").notNull(),
    seatType: mysqlEnum("seatType", ["standard", "premium"])
      .default("standard")
      .notNull(),
  },
  table => ({
    auditoriumIdx: index("seats_auditorium_idx").on(table.auditoriumId),
    auditoriumPosition: uniqueIndex("seats_auditorium_position_unique").on(
      table.auditoriumId,
      table.rowLabel,
      table.seatNumber
    ),
  })
);

export const movies = mysqlTable(
  "movies",
  {
    id: int("id").autoincrement().primaryKey(),
    slug: varchar("slug", { length: 80 }).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    synopsis: text("synopsis").notNull(),
    genres: varchar("genres", { length: 140 }).notNull(),
    durationMinutes: int("durationMinutes").notNull(),
    rating: decimal("rating", { precision: 2, scale: 1 }).notNull(),
    releaseDate: date("releaseDate", { mode: "string" }).notNull(),
    posterUrl: varchar("posterUrl", { length: 500 }).notNull(),
    hero: int("hero").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ slugUnique: uniqueIndex("movies_slug_unique").on(table.slug) })
);

export const showtimes = mysqlTable(
  "showtimes",
  {
    id: int("id").autoincrement().primaryKey(),
    movieId: int("movieId")
      .notNull()
      .references(() => movies.id, { onDelete: "cascade" }),
    auditoriumId: int("auditoriumId")
      .notNull()
      .references(() => auditoriums.id, { onDelete: "cascade" }),
    startsAt: datetime("startsAt").notNull(),
    language: varchar("language", { length: 40 }).default("English").notNull(),
    format: varchar("format", { length: 40 }).default("2D").notNull(),
    basePrice: decimal("basePrice", { precision: 8, scale: 2 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    scheduleIdx: index("showtimes_schedule_idx").on(
      table.startsAt,
      table.auditoriumId
    ),
    movieIdx: index("showtimes_movie_idx").on(table.movieId),
    uniqueScreening: uniqueIndex("showtimes_screening_unique").on(
      table.movieId,
      table.auditoriumId,
      table.startsAt
    ),
  })
);

export const customers = mysqlTable(
  "customers",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 254 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    emailUnique: uniqueIndex("customers_email_unique").on(table.email),
  })
);

export const bookings = mysqlTable(
  "bookings",
  {
    id: int("id").autoincrement().primaryKey(),
    reference: varchar("reference", { length: 20 }).notNull(),
    customerId: int("customerId")
      .notNull()
      .references(() => customers.id),
    showtimeId: int("showtimeId")
      .notNull()
      .references(() => showtimes.id),
    totalAmount: decimal("totalAmount", { precision: 9, scale: 2 }).notNull(),
    status: mysqlEnum("status", ["confirmed", "cancelled"])
      .default("confirmed")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    referenceUnique: uniqueIndex("bookings_reference_unique").on(
      table.reference
    ),
    customerIdx: index("bookings_customer_idx").on(table.customerId),
    showtimeIdx: index("bookings_showtime_idx").on(table.showtimeId),
  })
);

/** The unique showtime/seat key is the final concurrency-safe double-booking guard. */
export const bookingSeats = mysqlTable(
  "bookingSeats",
  {
    id: int("id").autoincrement().primaryKey(),
    bookingId: int("bookingId")
      .notNull()
      .references(() => bookings.id, { onDelete: "cascade" }),
    showtimeId: int("showtimeId")
      .notNull()
      .references(() => showtimes.id, { onDelete: "cascade" }),
    seatId: int("seatId")
      .notNull()
      .references(() => seats.id),
    price: decimal("price", { precision: 8, scale: 2 }).notNull(),
  },
  table => ({
    bookingIdx: index("booking_seats_booking_idx").on(table.bookingId),
    showtimeSeatUnique: uniqueIndex("booking_seats_showtime_seat_unique").on(
      table.showtimeId,
      table.seatId
    ),
    bookingSeatUnique: uniqueIndex("booking_seats_booking_seat_unique").on(
      table.bookingId,
      table.seatId
    ),
  })
);
