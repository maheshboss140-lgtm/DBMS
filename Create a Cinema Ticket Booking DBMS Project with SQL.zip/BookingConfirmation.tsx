import { Link, useRoute } from "wouter";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  Clock3,
  MapPin,
  Printer,
  Ticket,
} from "lucide-react";
import NotFound from "@/pages/NotFound";
import { trpc } from "@/lib/trpc";

function money(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export default function BookingConfirmation() {
  const [, params] = useRoute("/booking/:reference");
  const reference = params?.reference ?? "";
  const booking = trpc.cinema.bookingByReference.useQuery(
    { reference },
    { enabled: Boolean(reference), retry: false }
  );
  if (booking.isLoading)
    return <main className="confirmation-loading">Finding your ticket…</main>;
  if (
    booking.error?.data?.code === "NOT_FOUND" ||
    (booking.isSuccess && !booking.data)
  )
    return <NotFound />;
  if (booking.error)
    return (
      <main className="confirmation-loading">
        <p>We couldn’t retrieve that ticket.</p>
        <button className="text-action" onClick={() => booking.refetch()}>
          Try again
        </button>
        <Link href="/">Back to ReelBook</Link>
      </main>
    );
  const ticket = booking.data;
  if (!ticket) return <NotFound />;

  return (
    <div className="confirmation-page">
      <header className="confirmation-top">
        <Link href="/" className="brand">
          <span className="brand-mark">
            <Ticket size={18} />
          </span>
          <span>
            reelbook<span className="brand-dot">.</span>
          </span>
        </Link>
        <Link href="/" className="back-link">
          <ArrowLeft size={15} /> Back to the films
        </Link>
      </header>
      <main className="ticket-stage">
        <div className="confirmation-intro">
          <span className="confirmed-mark">
            <Check size={22} strokeWidth={2.5} />
          </span>
          <div className="eyebrow">
            <span className="eyebrow-line" /> ALL SET,{" "}
            {ticket.customer.name.split(" ")[0].toUpperCase()}
          </div>
          <h1>
            The night is <em>yours.</em>
          </h1>
          <p>Your seats are saved. Bring this little reference along.</p>
        </div>
        <article className="digital-ticket">
          <div className="digital-ticket-main">
            <div className="ticket-event-head">
              <span>ADMIT ONE · OR MORE</span>
              <span className="ticket-serial">
                NO. {ticket.id.toString().padStart(5, "0")}
              </span>
            </div>
            <div className="ticket-film-row">
              <img src={ticket.showtime.posterUrl} alt="" />
              <div>
                <div className="eyebrow">YOUR FEATURE</div>
                <h2>{ticket.showtime.movieTitle}</h2>
                <span>
                  {ticket.showtime.durationMinutes} min ·{" "}
                  {ticket.showtime.format} · {ticket.showtime.language}
                </span>
              </div>
            </div>
            <div className="ticket-detail-grid">
              <div>
                <span>
                  <CalendarDays size={13} /> DATE & TIME
                </span>
                <strong>
                  {new Intl.DateTimeFormat("en", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                  }).format(new Date(ticket.showtime.startsAt))}
                </strong>
                <small>
                  {new Intl.DateTimeFormat("en", {
                    hour: "numeric",
                    minute: "2-digit",
                  }).format(new Date(ticket.showtime.startsAt))}{" "}
                  · Arrive a little early
                </small>
              </div>
              <div>
                <span>
                  <MapPin size={13} /> THE CINEMA
                </span>
                <strong>{ticket.showtime.cinemaName}</strong>
                <small>
                  {ticket.showtime.neighborhood} ·{" "}
                  {ticket.showtime.auditoriumName}
                </small>
              </div>
              <div>
                <span>
                  <Ticket size={13} /> YOUR SEATS
                </span>
                <strong>
                  {ticket.seats.map(seat => seat.label).join(" · ")}
                </strong>
                <small>
                  {ticket.seats.length}{" "}
                  {ticket.seats.length === 1 ? "ticket" : "tickets"} ·{" "}
                  {ticket.showtime.screenType}
                </small>
              </div>
              <div>
                <span>
                  <Clock3 size={13} /> BOOKED FOR
                </span>
                <strong>{ticket.customer.name}</strong>
                <small>{ticket.customer.email}</small>
              </div>
            </div>
            <div className="ticket-total">
              <span>TOTAL PAID AT THE BOX OFFICE</span>
              <strong>{money(ticket.totalAmount)}</strong>
            </div>
          </div>
          <div className="ticket-perforation">
            <span />
            <div className="perforation-line" />
            <span />
          </div>
          <aside className="ticket-stub">
            <div className="ticket-stub-logo">
              <Ticket size={21} />
              <span>
                YOUR BOOKING
                <br />
                REFERENCE
              </span>
            </div>
            <strong className="ticket-reference">{ticket.reference}</strong>
            <p>
              Keep this code safe. You can use it to look up your booking any
              time.
            </p>
            <div
              className="barcode"
              aria-label={`Booking barcode for ${ticket.reference}`}
            >
              <span>|||| |||| || | ||| || |||||</span>
            </div>
            <span className="stub-admit">
              REELBOOK · GOOD STORIES LIVE HERE
            </span>
          </aside>
        </article>
        <div className="ticket-actions">
          <button onClick={() => window.print()} className="secondary-button">
            <Printer size={15} /> Print ticket
          </button>
          <Link href="/" className="primary-cta">
            Back to the marquee <ArrowLeft size={15} />
          </Link>
        </div>
      </main>
      <footer className="confirmation-footer">
        A good film is even better together. <span>— REELBOOK</span>
      </footer>
    </div>
  );
}
