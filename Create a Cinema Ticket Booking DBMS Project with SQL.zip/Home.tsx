import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  ChevronDown,
  Clapperboard,
  Clock3,
  Database,
  MapPin,
  Menu,
  Star,
  Ticket,
  X,
} from "lucide-react";
import BookingDialog from "@/components/BookingDialog";
import { trpc } from "@/lib/trpc";

function localDateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function money(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

function releaseLabel(releaseDate: string) {
  return new Intl.DateTimeFormat("en", {
    month: "short",
    year: "numeric",
  }).format(new Date(`${releaseDate}T00:00:00`));
}

export default function Home() {
  const [, navigate] = useLocation();
  const [cinemaId, setCinemaId] = useState<number | "all">("all");
  const [showDate, setShowDate] = useState(localDateKey(new Date()));
  const [activeShow, setActiveShow] = useState<number | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [lookupReference, setLookupReference] = useState("");
  const catalog = trpc.cinema.catalog.useQuery(undefined, {
    staleTime: 60_000,
  });
  const screenings = trpc.cinema.showtimes.useQuery(
    { date: showDate, cinemaId: cinemaId === "all" ? undefined : cinemaId },
    { staleTime: 30_000 }
  );
  const days = useMemo(
    () =>
      Array.from({ length: 5 }, (_, index) => {
        const day = new Date();
        day.setHours(12, 0, 0, 0);
        day.setDate(day.getDate() + index);
        return {
          key: localDateKey(day),
          weekday:
            index === 0
              ? "Today"
              : new Intl.DateTimeFormat("en", { weekday: "short" }).format(day),
          date: new Intl.DateTimeFormat("en", {
            day: "2-digit",
            month: "short",
          }).format(day),
        };
      }),
    []
  );
  const movies = catalog.data?.movies ?? [];
  const selectedMovie = movies.find(movie => movie.hero) ?? movies[0];
  const shows = screenings.data ?? [];
  const heroMovie = selectedMovie;

  function findTicket(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const reference = lookupReference.trim().toUpperCase();
    if (reference) navigate(`/booking/${encodeURIComponent(reference)}`);
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <Link href="/" className="brand" aria-label="ReelBook home">
          <span className="brand-mark">
            <Ticket size={19} strokeWidth={2.2} />
          </span>
          <span>
            reelbook<span className="brand-dot">.</span>
          </span>
        </Link>
        <button
          className="mobile-menu-toggle"
          onClick={() => setMobileMenu(value => !value)}
          aria-label="Toggle navigation"
        >
          {mobileMenu ? <X /> : <Menu />}
        </button>
        <nav className={`topnav ${mobileMenu ? "topnav-open" : ""}`}>
          <a
            className="nav-current"
            href="#now-showing"
            onClick={() => setMobileMenu(false)}
          >
            Now showing
          </a>
          <a href="#screenings" onClick={() => setMobileMenu(false)}>
            Showtimes
          </a>
          <a href="#ticket-lookup" onClick={() => setMobileMenu(false)}>
            Find a ticket
          </a>
          <Link href="/database" onClick={() => setMobileMenu(false)}>
            <Database size={14} /> The DBMS project
          </Link>
        </nav>
        <div className="topbar-right">
          <span className="city-status">
            <span className="status-dot" /> Find your screen
          </span>
          <a
            href="#screenings"
            className="round-link"
            aria-label="Jump to showtimes"
          >
            <ArrowDown size={17} />
          </a>
        </div>
      </header>

      <main>
        <section className="hero-wrap" aria-label="Featured movie">
          <div className="hero-media" />
          <div className="hero-shade" />
          <div className="hero-content">
            <div className="eyebrow hero-eyebrow">
              <span className="eyebrow-line" /> A little wonder, on the big
              screen
            </div>
            <div className="hero-film-mark">
              <span>REELBOOK PRESENTS</span>
              <span className="hero-mark-separator">/</span>
              <span>TONIGHT'S PICK</span>
            </div>
            <h1>
              {heroMovie?.title ?? "The best stories"}
              <br />
              <em>belong in the dark.</em>
            </h1>
            <p className="hero-copy">
              A good film. A great seat. That little moment before the lights go
              down.
            </p>
            {heroMovie && (
              <div className="hero-meta">
                <span>
                  <Star size={14} fill="currentColor" />{" "}
                  {Number(heroMovie.rating).toFixed(1)}
                </span>
                <i /> <span>{heroMovie.genres}</span>
                <i /> <span>{heroMovie.durationMinutes} min</span>
              </div>
            )}
            <a href="#screenings" className="primary-cta">
              Find a screening <ArrowRight size={16} />
            </a>
          </div>
          <div className="hero-caption">
            <span>01 — THE FEATURE PRESENTATION</span>
            <span>SETTLE IN, THE STORY'S ABOUT TO BEGIN</span>
          </div>
          <div className="hero-ticker">
            <span className="ticker-star">✳</span>
            <span>GOOD FILMS, GOOD SEATS, GOOD EVENINGS.</span>
            <span className="ticker-star">✳</span>
            <span>GOOD FILMS, GOOD SEATS, GOOD EVENINGS.</span>
            <span className="ticker-star">✳</span>
          </div>
        </section>

        <section
          className="content-section collection-section"
          id="now-showing"
        >
          <div className="section-heading">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-line" /> THE MARQUEE
              </div>
              <h2>
                On the <em>bill.</em>
              </h2>
            </div>
            <p className="section-note">
              Three stories. One very good reason to put your phone away.
            </p>
          </div>
          {catalog.isLoading ? (
            <div className="loading-note">Setting the scene…</div>
          ) : catalog.error ? (
            <div className="error-note">
              We couldn’t load the cinema listings.{" "}
              <button className="text-action" onClick={() => catalog.refetch()}>
                Try again <ArrowRight size={14} />
              </button>
              <small>{catalog.error.message}</small>
            </div>
          ) : (
            <div className="film-shelf">
              {movies.map((movie, index) => (
                <article
                  className={`film-card ${movie.hero ? "film-card-featured" : ""}`}
                  key={movie.id}
                >
                  <button
                    className="poster-button"
                    onClick={() =>
                      document
                        .getElementById("screenings")
                        ?.scrollIntoView({ behavior: "smooth" })
                    }
                    aria-label={`See showtimes for ${movie.title}`}
                  >
                    <img
                      className="poster-image"
                      src={movie.posterUrl}
                      alt={`Art for ${movie.title}`}
                      loading="lazy"
                    />
                    <span className="poster-index">0{index + 1}</span>
                    <span className="poster-book">
                      <Ticket size={16} />
                    </span>
                  </button>
                  <div className="film-title-row">
                    <h3>{movie.title}</h3>
                    <span className="film-rating">
                      <Star size={12} fill="currentColor" />{" "}
                      {Number(movie.rating).toFixed(1)}
                    </span>
                  </div>
                  <p className="film-subtitle">
                    {movie.genres} <span>·</span> {movie.durationMinutes} min
                    <span>·</span> Released {releaseLabel(movie.releaseDate)}
                  </p>
                  <p className="film-synopsis">{movie.synopsis}</p>
                </article>
              ))}
            </div>
          )}
          <div className="shelf-footnote">
            <span>CURATED FOR YOUR NEXT EVENING OUT</span>
            <span className="footnote-dots">
              ·······································
            </span>
            <span>THREE FILMS, ENDLESS WAYS TO FEEL</span>
          </div>
        </section>

        <section className="showtimes-section" id="screenings">
          <div className="showtimes-inner">
            <div className="section-heading showtimes-heading">
              <div>
                <div className="eyebrow">
                  <span className="eyebrow-line" /> THE DAILY BILL
                </div>
                <h2>
                  Pick your <em>moment.</em>
                </h2>
              </div>
              <div className="location-select-wrap">
                <MapPin size={15} />
                <select
                  value={cinemaId}
                  onChange={event =>
                    setCinemaId(
                      event.target.value === "all"
                        ? "all"
                        : Number(event.target.value)
                    )
                  }
                  aria-label="Choose cinema"
                >
                  <option value="all">All cinemas</option>
                  {catalog.data?.cinemas.map(cinema => (
                    <option key={cinema.id} value={cinema.id}>
                      {cinema.name}
                    </option>
                  ))}
                </select>
                <ChevronDown size={13} />
              </div>
            </div>
            <div className="cinema-directory" aria-label="Cinema venues">
              {catalog.data?.cinemas.map(cinema => (
                <button
                  type="button"
                  className={`venue-card ${cinemaId === cinema.id ? "venue-card-selected" : ""}`}
                  key={cinema.id}
                  aria-pressed={cinemaId === cinema.id}
                  onClick={() => setCinemaId(cinema.id)}
                >
                  <span className="venue-stub">
                    <MapPin size={15} />
                  </span>
                  <span className="venue-copy">
                    <strong>{cinema.name}</strong>
                    <small>
                      {cinema.neighborhood} · {cinema.address}
                    </small>
                  </span>
                  <ArrowUpRight className="venue-arrow" size={15} />
                </button>
              ))}
            </div>
            <div
              className="date-strip"
              role="tablist"
              aria-label="Choose a screening date"
            >
              {days.map(day => (
                <button
                  role="tab"
                  aria-selected={showDate === day.key}
                  className={`date-option ${showDate === day.key ? "date-selected" : ""}`}
                  key={day.key}
                  onClick={() => setShowDate(day.key)}
                >
                  <span>{day.weekday}</span>
                  <strong>{day.date}</strong>
                </button>
              ))}
            </div>
            <div className="showtime-list">
              {screenings.isLoading ? (
                <div className="loading-note">Checking tonight’s listings…</div>
              ) : screenings.error ? (
                <div className="error-note">
                  Screenings are taking a moment to load.{" "}
                  <button
                    className="text-action"
                    onClick={() => screenings.refetch()}
                  >
                    Retry
                  </button>
                </div>
              ) : (
                movies.map(movie => {
                  const movieShows = shows.filter(
                    show => show.movieId === movie.id
                  );
                  if (!movieShows.length) return null;
                  return (
                    <article className="show-row" key={movie.id}>
                      <img
                        className="show-row-poster"
                        src={movie.posterUrl}
                        alt=""
                        loading="lazy"
                      />
                      <div className="show-film-info">
                        <div className="show-film-name">
                          <h3>{movie.title}</h3>
                          <span className="film-rating">
                            <Star size={12} fill="currentColor" />{" "}
                            {Number(movie.rating).toFixed(1)}
                          </span>
                        </div>
                        <p>
                          {movie.genres} <span>·</span> <Clock3 size={12} />{" "}
                          {movie.durationMinutes} min
                        </p>
                      </div>
                      <div className="show-slots">
                        {movieShows.map(show => (
                          <button
                            className="show-slot"
                            key={show.id}
                            onClick={() => setActiveShow(show.id)}
                          >
                            <strong>
                              {new Intl.DateTimeFormat("en", {
                                hour: "numeric",
                                minute: "2-digit",
                              }).format(new Date(show.startsAt))}
                            </strong>
                            <span>
                              {show.neighborhood} · {show.format}
                            </span>
                            <span className="slot-price">
                              from {money(show.basePrice)}
                            </span>
                          </button>
                        ))}
                      </div>
                    </article>
                  );
                })
              )}
              {!screenings.isLoading &&
                !screenings.error &&
                shows.length === 0 && (
                  <div className="empty-shows">
                    <span className="empty-icon">
                      <Clapperboard size={20} />
                    </span>
                    <strong>No screenings on this date.</strong>
                    <p>Try another day or choose a different cinema.</p>
                  </div>
                )}
            </div>
            <div className="showtimes-tail">
              <span>SHOWTIMES ARE LOCAL TO EACH CINEMA</span>
              <span>SUBJECT TO AVAILABILITY</span>
            </div>
          </div>
        </section>

        <section className="lookup-strip" id="ticket-lookup">
          <div className="lookup-copy">
            <div className="eyebrow">
              <span className="eyebrow-line" /> ALREADY BOOKED?
            </div>
            <h2>
              Find your <em>ticket.</em>
            </h2>
            <p>
              Your booking reference is on your confirmation ticket. Enter it
              here to look up the details.
            </p>
          </div>
          <form className="lookup-form" onSubmit={findTicket}>
            <label htmlFor="booking-reference">BOOKING REFERENCE</label>
            <div className="lookup-input-row">
              <input
                id="booking-reference"
                value={lookupReference}
                onChange={event => setLookupReference(event.target.value)}
                required
                minLength={6}
                maxLength={20}
                autoComplete="off"
                placeholder="RB-7A2D19CF"
              />
              <button className="primary-cta" type="submit">
                Look up ticket <ArrowRight size={15} />
              </button>
            </div>
          </form>
        </section>

        <section className="dbms-banner">
          <div className="banner-stamp">
            <Database size={20} />
            <span>
              BUILT WITH
              <br />A LITTLE SQL
            </span>
          </div>
          <div className="banner-copy">
            <div className="eyebrow">MORE THAN JUST A PRETTY BOOKING FLOW</div>
            <h2>
              Curious how the <em>seats stay yours?</em>
            </h2>
            <p>
              Underneath every ticket is a relational database, a careful
              transaction, and a handful of very good constraints.
            </p>
          </div>
          <Link href="/database" className="banner-link">
            Explore the DBMS <ArrowUpRight size={17} />
          </Link>
          <span className="banner-watermark">SELECT · BOOK · CONFIRM</span>
        </section>
      </main>

      <footer className="footer">
        <Link href="/" className="brand footer-brand">
          <span className="brand-mark">
            <Ticket size={17} />
          </span>
          <span>
            reelbook<span className="brand-dot">.</span>
          </span>
        </Link>
        <span>AN ACADEMIC CINEMA BOOKING PROJECT</span>
        <span>MADE FOR PEOPLE WHO LOVE A GOOD STORY.</span>
      </footer>
      {activeShow !== null && (
        <BookingDialog
          showtimeId={activeShow}
          onClose={() => setActiveShow(null)}
          onBooked={reference => navigate(`/booking/${reference}`)}
        />
      )}
    </div>
  );
}
