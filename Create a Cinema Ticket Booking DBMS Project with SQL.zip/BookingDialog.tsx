import { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  Check,
  LoaderCircle,
  MapPin,
  Minus,
  Plus,
  Ticket,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

type Props = {
  showtimeId: number;
  onClose: () => void;
  onBooked: (reference: string) => void;
};

function money(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export default function BookingDialog({
  showtimeId,
  onClose,
  onBooked,
}: Props) {
  const [selected, setSelected] = useState<number[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notice, setNotice] = useState("");
  const utils = trpc.useUtils();
  const availability = trpc.cinema.availability.useQuery({ showtimeId });
  const book = trpc.cinema.book.useMutation({
    onSuccess: async ({ reference }) => {
      await utils.cinema.availability.invalidate({ showtimeId });
      onBooked(reference);
    },
    onError: error => setNotice(error.message),
  });
  const seats = availability.data?.seats ?? [];
  const show = availability.data?.showtime;
  const byRow = useMemo(
    () =>
      seats.reduce<Record<string, typeof seats>>((groups, seat) => {
        (groups[seat.rowLabel] ??= []).push(seat);
        return groups;
      }, {}),
    [seats]
  );
  const total = (show?.basePrice ?? 0) * selected.length;

  useEffect(() => {
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = original;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  function toggleSeat(id: number) {
    setNotice("");
    setSelected(current =>
      current.includes(id)
        ? current.filter(seat => seat !== id)
        : current.length >= 8
          ? current
          : [...current, id]
    );
  }

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected.length) {
      setNotice("Choose at least one seat to continue.");
      return;
    }
    book.mutate({
      showtimeId,
      seatIds: selected,
      customer: { name: name.trim(), email: email.trim(), phone: phone.trim() },
    });
  }

  return (
    <div
      className="dialog-backdrop"
      role="presentation"
      onMouseDown={event => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="booking-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-title"
      >
        <header className="dialog-header">
          <div>
            <div className="eyebrow">
              <span className="eyebrow-line" /> YOUR EVENING, YOUR WAY
            </div>
            <h2 id="booking-title">
              Choose your <em>seats.</em>
            </h2>
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Close seat selection"
          >
            <X size={19} />
          </button>
        </header>
        {availability.isLoading ? (
          <div className="loading-note dialog-loading">
            <LoaderCircle className="spin" /> Finding your screen…
          </div>
        ) : availability.error ? (
          <div className="dialog-error">
            <AlertCircle />
            <p>{availability.error.message}</p>
            <button
              className="secondary-button"
              onClick={() => availability.refetch()}
            >
              Try again
            </button>
          </div>
        ) : (
          show && (
            <>
              <div className="screening-summary">
                <div>
                  <strong>{show.movieTitle}</strong>
                  <span>
                    <MapPin size={12} /> {show.cinemaName}, {show.neighborhood}{" "}
                    · {show.auditoriumName}
                  </span>
                </div>
                <div className="screening-time">
                  <strong>
                    {new Intl.DateTimeFormat("en", {
                      weekday: "short",
                      day: "numeric",
                      month: "short",
                      hour: "numeric",
                      minute: "2-digit",
                    }).format(new Date(show.startsAt))}
                  </strong>
                  <span>
                    {show.format} · {show.language}
                  </span>
                </div>
              </div>
              <div className="seat-area">
                <div className="screen-arch">
                  <div className="screen-light" />
                  <span>SCREEN THIS WAY</span>
                </div>
                <div className="seat-legend">
                  <span>
                    <i className="legend-seat seat-available" /> Available
                  </span>
                  <span>
                    <i className="legend-seat seat-selected" /> Selected
                  </span>
                  <span>
                    <i className="legend-seat seat-booked" /> Booked
                  </span>
                </div>
                <div className="seat-map" aria-label="Choose seats">
                  {Object.entries(byRow).map(([row, rowSeats]) => (
                    <div className="seat-row" key={row}>
                      <span className="seat-row-label">{row}</span>
                      {rowSeats.map((seat, index) => {
                        const isSelected = selected.includes(seat.id);
                        const isBooked = seat.status === "booked";
                        return (
                          <span
                            className={`seat-cell ${index === 5 ? "seat-aisle" : ""}`}
                            key={seat.id}
                          >
                            <button
                              type="button"
                              disabled={isBooked}
                              aria-pressed={isSelected}
                              aria-label={`Seat ${row}${seat.seatNumber}, ${isBooked ? "booked" : isSelected ? "selected" : "available"}`}
                              onClick={() => toggleSeat(seat.id)}
                              className={`seat ${isBooked ? "seat-booked" : isSelected ? "seat-selected" : seat.seatType === "premium" ? "seat-premium" : "seat-available"}`}
                            >
                              {isSelected ? (
                                <Check size={11} />
                              ) : (
                                seat.seatNumber
                              )}
                            </button>
                          </span>
                        );
                      })}
                      <span className="seat-row-label">{row}</span>
                    </div>
                  ))}
                </div>
                <div className="seat-limit-note">
                  <Minus size={11} /> UP TO 8 SEATS <Plus size={11} />
                </div>
              </div>
              <form className="customer-form" onSubmit={submit}>
                <div className="ticket-summary">
                  <div className="summary-ticket-icon">
                    <Ticket size={17} />
                  </div>
                  <div className="summary-main">
                    <span>
                      YOUR TICKETS{" "}
                      <strong>
                        {selected.length}{" "}
                        {selected.length === 1 ? "SEAT" : "SEATS"}
                      </strong>
                    </span>
                    <small>
                      {selected.length
                        ? selected
                            .map(id => {
                              const seat = seats.find(item => item.id === id);
                              return seat
                                ? `${seat.rowLabel}${seat.seatNumber}`
                                : "";
                            })
                            .join(" · ")
                        : "Select a seat to begin"}
                    </small>
                  </div>
                  <strong className="summary-total">{money(total)}</strong>
                </div>
                {notice && (
                  <div className="form-notice" role="alert">
                    <AlertCircle size={15} />
                    {notice}
                  </div>
                )}
                <div className="form-fields">
                  <label>
                    YOUR NAME
                    <input
                      required
                      minLength={2}
                      maxLength={160}
                      autoComplete="name"
                      value={name}
                      onChange={event => setName(event.target.value)}
                      placeholder="Alex Morgan"
                    />
                  </label>
                  <label>
                    EMAIL ADDRESS
                    <input
                      required
                      type="email"
                      maxLength={254}
                      autoComplete="email"
                      value={email}
                      onChange={event => setEmail(event.target.value)}
                      placeholder="alex@example.com"
                    />
                  </label>
                  <label>
                    PHONE
                    <input
                      required
                      minLength={7}
                      maxLength={32}
                      type="tel"
                      autoComplete="tel"
                      value={phone}
                      onChange={event => setPhone(event.target.value)}
                      placeholder="+91 98765 43210"
                    />
                  </label>
                </div>
                <button
                  className="primary-cta book-submit"
                  type="submit"
                  disabled={book.isPending || selected.length === 0}
                >
                  {book.isPending ? (
                    <>
                      <LoaderCircle className="spin" size={17} /> Reserving your
                      seats…
                    </>
                  ) : (
                    <>
                      Confirm booking <span>{money(total)}</span>
                    </>
                  )}
                </button>
                <p className="booking-disclaimer">
                  No payment required · Your seats are reserved together
                </p>
              </form>
            </>
          )
        )}
      </section>
    </div>
  );
}
