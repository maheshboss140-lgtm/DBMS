import { randomBytes } from "node:crypto";
import { and, asc, eq, gte, inArray, lt, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import {
  auditoriums,
  bookingSeats,
  bookings,
  cinemas,
  customers,
  movies,
  seats,
  showtimes,
} from "../drizzle/schema";

const poster = {
  orbit: "/manus-storage/async-images/RcaF8OqPyVNz3J0xjAuj7K/image-2.webp",
  summer: "/manus-storage/async-images/RcaF8OqPyVNz3J0xjAuj7K/image-3.webp",
  midnight: "/manus-storage/async-images/RcaF8OqPyVNz3J0xjAuj7K/image-4.webp",
};

function requireDb() {
  return getDb().then(db => {
    if (!db)
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "The cinema database is unavailable.",
      });
    return db;
  });
}

async function seedDemoCatalog() {
  const db = await requireDb();
  const [cinemaRows, auditoriumRows, movieRows] = await Promise.all([
    db.select({ id: cinemas.id }).from(cinemas).limit(1),
    db.select({ id: auditoriums.id }).from(auditoriums).limit(1),
    db.select({ id: movies.id }).from(movies).limit(1),
  ]);
  if (!cinemaRows.length) {
    await db
      .insert(cinemas)
      .values([
        {
          id: 1,
          slug: "the-grand-arcade",
          name: "The Grand Arcade",
          neighborhood: "Old Town",
          address: "14 Crescent Avenue, Old Town",
        },
        {
          id: 2,
          slug: "northstar-picture-house",
          name: "Northstar Picture House",
          neighborhood: "Riverside",
          address: "6 Riverside Walk, North Quarter",
        },
      ])
      .onDuplicateKeyUpdate({ set: { id: sql`id` } });
  }
  if (!auditoriumRows.length) {
    await db
      .insert(auditoriums)
      .values([
        { id: 101, cinemaId: 1, name: "Screen One", screenType: "Dolby Atmos" },
        { id: 102, cinemaId: 1, name: "Screen Two", screenType: "Laser 2D" },
        {
          id: 201,
          cinemaId: 2,
          name: "The Main Room",
          screenType: "Dolby Atmos",
        },
      ])
      .onDuplicateKeyUpdate({ set: { id: sql`id` } });
  }
  if (!movieRows.length) {
    await db
      .insert(movies)
      .values([
        {
          id: 1,
          slug: "orbit-nine",
          title: "Orbit Nine",
          synopsis:
            "A cartographer stranded on a quiet moon finds a signal that may lead her home — or pull her further from it.",
          genres: "Science fiction · Adventure",
          durationMinutes: 128,
          rating: "8.4",
          releaseDate: "2026-10-23",
          posterUrl: poster.orbit,
          hero: 1,
        },
        {
          id: 2,
          slug: "the-summer-between",
          title: "The Summer Between",
          synopsis:
            "Two old friends have one long summer to say the things they left unsaid.",
          genres: "Romance · Drama",
          durationMinutes: 114,
          rating: "8.1",
          releaseDate: "2026-10-16",
          posterUrl: poster.summer,
          hero: 0,
        },
        {
          id: 3,
          slug: "after-the-last-train",
          title: "After the Last Train",
          synopsis:
            "One missed train. One locked station. A night that refuses to stay ordinary.",
          genres: "Mystery · Thriller",
          durationMinutes: 108,
          rating: "7.9",
          releaseDate: "2026-10-30",
          posterUrl: poster.midnight,
          hero: 0,
        },
      ])
      .onDuplicateKeyUpdate({ set: { id: sql`id` } });
  }

  const slots = [
    {
      movieId: 1,
      auditoriumId: 101,
      time: "17:15",
      price: "280.00",
      format: "2D",
    },
    {
      movieId: 2,
      auditoriumId: 101,
      time: "20:30",
      price: "320.00",
      format: "2D",
    },
    {
      movieId: 3,
      auditoriumId: 102,
      time: "18:00",
      price: "300.00",
      format: "2D",
    },
    {
      movieId: 1,
      auditoriumId: 102,
      time: "21:15",
      price: "340.00",
      format: "Laser",
    },
    {
      movieId: 3,
      auditoriumId: 201,
      time: "16:30",
      price: "280.00",
      format: "2D",
    },
    {
      movieId: 2,
      auditoriumId: 201,
      time: "19:45",
      price: "300.00",
      format: "2D",
    },
    {
      movieId: 1,
      auditoriumId: 201,
      time: "14:00",
      price: "260.00",
      format: "2D",
    },
  ];
  const now = new Date();
  const scheduled = [];
  for (let offset = 0; offset < 7; offset += 1) {
    const day = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + offset
    );
    for (const slot of slots) {
      const [hours, minutes] = slot.time.split(":").map(Number);
      const startsAt = new Date(
        day.getFullYear(),
        day.getMonth(),
        day.getDate(),
        hours,
        minutes,
        0,
        0
      );
      if (startsAt <= now) continue;
      scheduled.push({
        movieId: slot.movieId,
        auditoriumId: slot.auditoriumId,
        startsAt,
        basePrice: slot.price,
        format: slot.format,
        language: "English",
      });
    }
  }
  if (scheduled.length)
    await db
      .insert(showtimes)
      .values(scheduled)
      .onDuplicateKeyUpdate({ set: { id: sql`id` } });

  const seatRows = ["A", "B", "C", "D", "E"];
  const seatValues = [101, 102, 201].flatMap(auditoriumId =>
    seatRows.flatMap((rowLabel, rowIndex) =>
      Array.from({ length: 10 }, (_, seatIndex) => ({
        id: auditoriumId * 1000 + rowIndex * 10 + seatIndex + 1,
        auditoriumId,
        rowLabel,
        seatNumber: seatIndex + 1,
        seatType: rowIndex >= 3 ? ("premium" as const) : ("standard" as const),
      }))
    )
  );
  await db
    .insert(seats)
    .values(seatValues)
    .onDuplicateKeyUpdate({ set: { id: sql`id` } });
}

export async function getCatalog() {
  await seedDemoCatalog();
  const db = await requireDb();
  const [cinemaList, movieList] = await Promise.all([
    db.select().from(cinemas).orderBy(asc(cinemas.name)),
    db.select().from(movies).orderBy(asc(movies.id)),
  ]);
  return {
    cinemas: cinemaList,
    movies: movieList.map(movie => ({
      ...movie,
      rating: Number(movie.rating),
    })),
  };
}

export async function getShowtimes(dateKey: string, cinemaId?: number) {
  await seedDemoCatalog();
  const db = await requireDb();
  const start = new Date(`${dateKey}T00:00:00`);
  if (Number.isNaN(start.getTime()))
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Choose a valid screening date.",
    });
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  const rows = await db
    .select({
      id: showtimes.id,
      movieId: movies.id,
      movieTitle: movies.title,
      posterUrl: movies.posterUrl,
      rating: movies.rating,
      durationMinutes: movies.durationMinutes,
      cinemaId: cinemas.id,
      cinemaName: cinemas.name,
      neighborhood: cinemas.neighborhood,
      address: cinemas.address,
      auditoriumName: auditoriums.name,
      screenType: auditoriums.screenType,
      startsAt: showtimes.startsAt,
      basePrice: showtimes.basePrice,
      format: showtimes.format,
      language: showtimes.language,
    })
    .from(showtimes)
    .innerJoin(movies, eq(showtimes.movieId, movies.id))
    .innerJoin(auditoriums, eq(showtimes.auditoriumId, auditoriums.id))
    .innerJoin(cinemas, eq(auditoriums.cinemaId, cinemas.id))
    .where(
      and(
        gte(showtimes.startsAt, start),
        lt(showtimes.startsAt, end),
        cinemaId ? eq(cinemas.id, cinemaId) : undefined
      )
    )
    .orderBy(asc(showtimes.startsAt));
  return rows.map(row => ({
    ...row,
    rating: Number(row.rating),
    basePrice: Number(row.basePrice),
  }));
}

export async function getShowtimeAvailability(showtimeId: number) {
  const db = await requireDb();
  const [screening] = await db
    .select({
      id: showtimes.id,
      movieId: movies.id,
      movieTitle: movies.title,
      posterUrl: movies.posterUrl,
      cinemaName: cinemas.name,
      neighborhood: cinemas.neighborhood,
      auditoriumId: auditoriums.id,
      auditoriumName: auditoriums.name,
      screenType: auditoriums.screenType,
      startsAt: showtimes.startsAt,
      basePrice: showtimes.basePrice,
      format: showtimes.format,
      language: showtimes.language,
    })
    .from(showtimes)
    .innerJoin(movies, eq(showtimes.movieId, movies.id))
    .innerJoin(auditoriums, eq(showtimes.auditoriumId, auditoriums.id))
    .innerJoin(cinemas, eq(auditoriums.cinemaId, cinemas.id))
    .where(eq(showtimes.id, showtimeId))
    .limit(1);
  if (!screening)
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "That screening could not be found.",
    });
  const [seatList, reservations] = await Promise.all([
    db
      .select()
      .from(seats)
      .where(eq(seats.auditoriumId, screening.auditoriumId))
      .orderBy(asc(seats.rowLabel), asc(seats.seatNumber)),
    db
      .select({ seatId: bookingSeats.seatId })
      .from(bookingSeats)
      .where(eq(bookingSeats.showtimeId, showtimeId)),
  ]);
  const occupied = new Set(reservations.map(row => row.seatId));
  return {
    showtime: { ...screening, basePrice: Number(screening.basePrice) },
    seats: seatList.map(seat => ({
      ...seat,
      status: occupied.has(seat.id)
        ? ("booked" as const)
        : ("available" as const),
    })),
  };
}

export type BookingRequest = {
  showtimeId: number;
  seatIds: number[];
  customer: { name: string; email: string; phone: string };
};

export async function createBooking(input: BookingRequest) {
  const db = await requireDb();
  const seatIds = [...new Set(input.seatIds)].sort((a, b) => a - b);
  if (seatIds.length !== input.seatIds.length)
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Each seat can only be added once.",
    });

  try {
    const reference = `RB-${randomBytes(4).toString("hex").toUpperCase()}`;
    await db.transaction(async tx => {
      const [screening] = await tx
        .select({
          id: showtimes.id,
          auditoriumId: showtimes.auditoriumId,
          startsAt: showtimes.startsAt,
          basePrice: showtimes.basePrice,
        })
        .from(showtimes)
        .where(eq(showtimes.id, input.showtimeId))
        .limit(1);
      if (!screening || new Date(screening.startsAt).getTime() <= Date.now()) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "That screening is no longer available.",
        });
      }
      const validSeats = await tx
        .select({ id: seats.id })
        .from(seats)
        .where(
          and(
            eq(seats.auditoriumId, screening.auditoriumId),
            inArray(seats.id, seatIds)
          )
        );
      if (validSeats.length !== seatIds.length)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "One or more seats are not part of this screen.",
        });
      const occupied = await tx
        .select({ seatId: bookingSeats.seatId })
        .from(bookingSeats)
        .where(
          and(
            eq(bookingSeats.showtimeId, input.showtimeId),
            inArray(bookingSeats.seatId, seatIds)
          )
        );
      if (occupied.length)
        throw new TRPCError({
          code: "CONFLICT",
          message: "One of those seats was just booked. Please choose another.",
        });

      await tx
        .insert(customers)
        .values(input.customer)
        .onDuplicateKeyUpdate({
          set: {
            name: input.customer.name,
            phone: input.customer.phone,
            updatedAt: new Date(),
          },
        });
      const [customer] = await tx
        .select({ id: customers.id })
        .from(customers)
        .where(eq(customers.email, input.customer.email))
        .limit(1);
      if (!customer)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "We could not save your booking details.",
        });

      const total = Number(screening.basePrice) * seatIds.length;
      await tx.insert(bookings).values({
        reference,
        customerId: customer.id,
        showtimeId: input.showtimeId,
        totalAmount: total.toFixed(2),
        status: "confirmed",
      });
      const [booking] = await tx
        .select({ id: bookings.id })
        .from(bookings)
        .where(eq(bookings.reference, reference))
        .limit(1);
      if (!booking)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "We could not create your booking.",
        });
      await tx.insert(bookingSeats).values(
        seatIds.map(seatId => ({
          bookingId: booking.id,
          showtimeId: input.showtimeId,
          seatId,
          price: Number(screening.basePrice).toFixed(2),
        }))
      );
    });
    return { reference };
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    const code = (error as { code?: string }).code;
    if (code === "ER_DUP_ENTRY" || code === "1062") {
      throw new TRPCError({
        code: "CONFLICT",
        message: "One of those seats was just booked. Please choose another.",
      });
    }
    console.error("[Cinema] Booking transaction failed:", error);
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Booking could not be completed. Please try again.",
    });
  }
}

export async function getBookingByReference(reference: string) {
  const db = await requireDb();
  const [booking] = await db
    .select()
    .from(bookings)
    .where(eq(bookings.reference, reference.toUpperCase()))
    .limit(1);
  if (!booking) return null;
  const [[customer], [screening], reserved] = await Promise.all([
    db
      .select()
      .from(customers)
      .where(eq(customers.id, booking.customerId))
      .limit(1),
    db
      .select({
        startsAt: showtimes.startsAt,
        format: showtimes.format,
        language: showtimes.language,
        auditoriumName: auditoriums.name,
        screenType: auditoriums.screenType,
        cinemaName: cinemas.name,
        address: cinemas.address,
        neighborhood: cinemas.neighborhood,
        movieTitle: movies.title,
        posterUrl: movies.posterUrl,
        durationMinutes: movies.durationMinutes,
      })
      .from(showtimes)
      .innerJoin(auditoriums, eq(showtimes.auditoriumId, auditoriums.id))
      .innerJoin(cinemas, eq(auditoriums.cinemaId, cinemas.id))
      .innerJoin(movies, eq(showtimes.movieId, movies.id))
      .where(eq(showtimes.id, booking.showtimeId))
      .limit(1),
    db
      .select({
        rowLabel: seats.rowLabel,
        seatNumber: seats.seatNumber,
        seatType: seats.seatType,
      })
      .from(bookingSeats)
      .innerJoin(seats, eq(bookingSeats.seatId, seats.id))
      .where(eq(bookingSeats.bookingId, booking.id))
      .orderBy(asc(seats.rowLabel), asc(seats.seatNumber)),
  ]);
  if (!customer || !screening) return null;
  return {
    ...booking,
    totalAmount: Number(booking.totalAmount),
    customer,
    showtime: screening,
    seats: reserved.map(seat => ({
      ...seat,
      label: `${seat.rowLabel}${seat.seatNumber}`,
    })),
  };
}
