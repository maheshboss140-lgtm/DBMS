import { useState } from "react";
import { Link } from "wouter";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Copy,
  Database,
  KeyRound,
  Link2,
  Ticket,
} from "lucide-react";

const schema = [
  {
    name: "cinemas",
    key: "PK id",
    fields: "slug · name · neighborhood · address",
    accent: "entity-cinema",
  },
  {
    name: "auditoriums",
    key: "PK id · FK cinemaId",
    fields: "name · screenType",
    accent: "entity-hall",
  },
  {
    name: "seats",
    key: "PK id · FK auditoriumId",
    fields: "rowLabel · seatNumber · seatType",
    accent: "entity-seat",
  },
  {
    name: "movies",
    key: "PK id",
    fields: "title · synopsis · genres · rating · posterUrl",
    accent: "entity-movie",
  },
  {
    name: "showtimes",
    key: "PK id · FK movieId · FK auditoriumId",
    fields: "startsAt · format · basePrice",
    accent: "entity-show",
  },
  {
    name: "customers",
    key: "PK id · UQ email",
    fields: "name · email · phone",
    accent: "entity-customer",
  },
  {
    name: "bookings",
    key: "PK id · FK customerId · FK showtimeId",
    fields: "reference · totalAmount · status",
    accent: "entity-booking",
  },
  {
    name: "bookingSeats",
    key: "PK id · FK bookingId · FK showtimeId · FK seatId",
    fields: "price · UNIQUE(showtimeId, seatId)",
    accent: "entity-reservation",
  },
];

const queryExamples = [
  {
    title: "01 · Find screenings for a date",
    description:
      "Join movies to auditoriums, then to their cinema. The date is a query parameter, never a SQL string concatenation.",
    sql: `SELECT\n  m.title, c.name AS cinema, a.name AS screen,\n  s.startsAt, s.format, s.basePrice\nFROM showtimes AS s\nJOIN movies AS m ON m.id = s.movieId\nJOIN auditoriums AS a ON a.id = s.auditoriumId\nJOIN cinemas AS c ON c.id = a.cinemaId\nWHERE DATE(s.startsAt) = '2026-11-01'\nORDER BY s.startsAt;`,
  },
  {
    title: "02 · Read seats for a showtime",
    description:
      "A seat is occupied only when a bookingSeats row exists for this showtime and seat.",
    sql: `SELECT\n  st.rowLabel, st.seatNumber, st.seatType,\n  CASE WHEN bs.id IS NULL THEN 'available' ELSE 'booked' END AS seatStatus\nFROM seats AS st\nLEFT JOIN bookingSeats AS bs\n  ON bs.seatId = st.id AND bs.showtimeId = 42\nWHERE st.auditoriumId = 101\nORDER BY st.rowLabel, st.seatNumber;`,
  },
  {
    title: "03 · Reserve as one transaction",
    description:
      "The write set is grouped in one transaction. The composite unique index is the final guard against concurrent bookings.",
    sql: `START TRANSACTION;\nSELECT id FROM seats\nWHERE id IN (101001, 101002) AND auditoriumId = 101;\n\nINSERT INTO bookings (reference, customerId, showtimeId, totalAmount)\nVALUES ('RB-7A2D19CF', 15, 42, 560.00);\n\nINSERT INTO bookingSeats (bookingId, showtimeId, seatId, price)\nVALUES (88, 42, 1001, 280.00), (88, 42, 1002, 280.00);\nCOMMIT;`,
  },
  {
    title: "04 · Booking-seat integrity rule",
    description:
      "This unique composite key makes two confirmed reservations for the same seat and showtime impossible.",
    sql: `ALTER TABLE bookingSeats\n  ADD CONSTRAINT uq_showtime_seat\n  UNIQUE (showtimeId, seatId);\n\n-- Referential integrity also protects each link.\nALTER TABLE bookingSeats\n  ADD CONSTRAINT fk_bookingSeats_showtime\n  FOREIGN KEY (showtimeId) REFERENCES showtimes(id);`,
  },
  {
    title: "05 · Customer booking history",
    description:
      "The normalized booking link lets a customer have many bookings without repeating their contact details.",
    sql: `SELECT b.reference, m.title, s.startsAt, b.totalAmount,\n       GROUP_CONCAT(CONCAT(st.rowLabel, st.seatNumber)\n                    ORDER BY st.rowLabel, st.seatNumber) AS seats\nFROM bookings AS b\nJOIN showtimes AS s ON s.id = b.showtimeId\nJOIN movies AS m ON m.id = s.movieId\nJOIN bookingSeats AS bs ON bs.bookingId = b.id\nJOIN seats AS st ON st.id = bs.seatId\nWHERE b.customerId = 15\nGROUP BY b.id, b.reference, m.title, s.startsAt, b.totalAmount\nORDER BY b.createdAt DESC;`,
  },
];

const relations = [
  { from: "cinemas", cardinality: "1 : N", to: "auditoriums" },
  { from: "auditoriums", cardinality: "1 : N", to: "seats" },
  { from: "auditoriums", cardinality: "1 : N", to: "showtimes" },
  { from: "movies", cardinality: "1 : N", to: "showtimes" },
  { from: "customers", cardinality: "1 : N", to: "bookings" },
  { from: "showtimes", cardinality: "1 : N", to: "bookings" },
  { from: "bookings", cardinality: "1 : N", to: "bookingSeats" },
  { from: "seats", cardinality: "1 : N", to: "bookingSeats" },
];

export default function DatabaseDesign() {
  const [copied, setCopied] = useState<number | null>(null);
  async function copySql(index: number, sql: string) {
    try {
      await navigator.clipboard.writeText(sql);
      setCopied(index);
      window.setTimeout(() => setCopied(null), 1400);
    } catch {
      setCopied(null);
    }
  }

  return (
    <div className="db-page">
      <header className="db-topbar">
        <Link href="/" className="brand">
          <span className="brand-mark">
            <Ticket size={18} />
          </span>
          <span>
            reelbook<span className="brand-dot">.</span>
          </span>
        </Link>
        <Link href="/" className="back-link">
          <ArrowLeft size={15} /> Back to the films
        </Link>
      </header>
      <main className="db-main">
        <section className="db-hero">
          <div className="eyebrow">
            <span className="eyebrow-line" /> UNDER THE HOOD
          </div>
          <h1>
            A seat for every story.
            <br />
            <em>A row for every relationship.</em>
          </h1>
          <p>
            This is the relational model behind ReelBook: eight small tables, a
            few well-chosen keys, and one transaction that keeps your seats
            together.
          </p>
          <div className="db-hero-meta">
            <span>
              <Database size={14} /> MySQL · Drizzle ORM
            </span>
            <i />
            <span>a compact relational model</span>
            <i />
            <span>8 core tables</span>
          </div>
        </section>
        <section className="db-section">
          <div className="db-section-title">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-line" /> 01 — THE ER MODEL
              </div>
              <h2>
                How the pieces <em>connect.</em>
              </h2>
            </div>
            <span className="diagram-note">
              <KeyRound size={13} /> PK = primary key&nbsp;&nbsp; ·
              &nbsp;&nbsp;FK = foreign key
            </span>
          </div>
          <div className="erd-panel">
            <div className="erd-head">
              <span>REELBOOK · ENTITY RELATIONSHIP DIAGRAM</span>
              <span>8 ENTITIES / 8 RELATIONSHIPS</span>
            </div>
            <div className="erd-canvas">
              <svg
                className="erd-lines"
                viewBox="0 0 1040 470"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
                <path d="M175 110 H235" />
                <path d="M365 110 H420" />
                <path d="M175 150 C220 250 260 315 320 340" />
                <path d="M497 110 C565 85 610 85 660 110" />
                <path d="M497 130 C565 180 610 165 660 140" />
                <path d="M812 105 H860" />
                <path d="M812 140 C840 185 840 285 860 320" />
                <path d="M510 340 H590" />
                <path d="M510 370 C650 440 785 420 860 375" />
                <path d="M385 380 C570 450 765 435 860 370" />
              </svg>
              <div
                className="erd-entity entity-cinema"
                style={{ left: "3%", top: "13%" }}
              >
                <strong>cinemas</strong>
                <span>PK&nbsp; id</span>
                <small>name · neighborhood</small>
              </div>
              <div
                className="erd-entity entity-hall"
                style={{ left: "25%", top: "13%" }}
              >
                <strong>auditoriums</strong>
                <span>PK&nbsp; id&nbsp;&nbsp; FK&nbsp; cinemaId</span>
                <small>name · screenType</small>
              </div>
              <div
                className="erd-entity entity-seat"
                style={{ left: "42%", top: "60%" }}
              >
                <strong>seats</strong>
                <span>PK&nbsp; id&nbsp;&nbsp; FK&nbsp; auditoriumId</span>
                <small>rowLabel · seatNumber · type</small>
              </div>
              <div
                className="erd-entity entity-movie"
                style={{ left: "43%", top: "13%" }}
              >
                <strong>movies</strong>
                <span>PK&nbsp; id</span>
                <small>title · genres · duration</small>
              </div>
              <div
                className="erd-entity entity-show"
                style={{ left: "64%", top: "13%" }}
              >
                <strong>showtimes</strong>
                <span>PK&nbsp; id&nbsp;&nbsp; FK&nbsp; movieId</span>
                <small>FK auditoriumId · startsAt · price</small>
              </div>
              <div
                className="erd-entity entity-customer"
                style={{ left: "82%", top: "13%" }}
              >
                <strong>customers</strong>
                <span>PK&nbsp; id&nbsp;&nbsp; UQ&nbsp; email</span>
                <small>name · email · phone</small>
              </div>
              <div
                className="erd-entity entity-booking"
                style={{ left: "82%", top: "60%" }}
              >
                <strong>bookings</strong>
                <span>PK&nbsp; id&nbsp;&nbsp; FK customerId</span>
                <small>FK showtimeId · reference · total</small>
              </div>
              <div
                className="erd-entity entity-reservation"
                style={{ left: "59%", top: "68%" }}
              >
                <strong>bookingSeats</strong>
                <span>FK bookingId · FK showtimeId</span>
                <small>FK seatId · UNIQUE(showtimeId, seatId)</small>
              </div>
              <span
                className="erd-cardinality"
                style={{ left: "20%", top: "16%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "38%", top: "17%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "57%", top: "16%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "78%", top: "17%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "80%", top: "54%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "74%", top: "68%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "54%", top: "64%" }}
              >
                1 : N
              </span>
              <span
                className="erd-cardinality"
                style={{ left: "42%", top: "61%" }}
              >
                1 : N
              </span>
            </div>
            <div className="erd-foot">
              <span>
                <i className="erd-key" /> BOOKING_SEATS IS THE RESERVATION
                BRIDGE
              </span>
              <span>NO SEAT. NO TICKET. NO DOUBLE BOOKING.</span>
            </div>
          </div>
        </section>
        <section className="db-section relation-section">
          <div className="db-section-title">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-line" /> 02 — RELATIONAL SCHEMA
              </div>
              <h2>
                Entities, <em>spelled out.</em>
              </h2>
            </div>
            <p>
              Every relationship is backed by a foreign key. The schema
              normalizes customers, films, and places so each fact has a single
              home.
            </p>
          </div>
          <div className="schema-grid">
            {schema.map(entity => (
              <article
                className={`schema-card ${entity.accent}`}
                key={entity.name}
              >
                <div className="schema-card-head">
                  <span className="schema-table-icon">
                    <Database size={14} />
                  </span>
                  <strong>{entity.name}</strong>
                </div>
                <span className="schema-keys">
                  <KeyRound size={11} /> {entity.key}
                </span>
                <p>{entity.fields}</p>
              </article>
            ))}
          </div>
          <div className="key-callout">
            <span className="key-callout-icon">
              <Link2 size={18} />
            </span>
            <p>
              <strong>Why a bridge table?</strong> A booking may hold multiple
              seats, and a seat appears in many showtimes.{" "}
              <code>bookingSeats</code> records the chosen seat for one
              screening and resolves that many-to-many relationship.
            </p>
            <ArrowRight size={16} />
          </div>
        </section>
        <section className="db-section query-section">
          <div className="db-section-title">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-line" /> 03 — SQL NOTEBOOK
              </div>
              <h2>
                Queries worth <em>keeping.</em>
              </h2>
            </div>
            <p>
              Small examples you can run, explain, and adapt for a DBMS project
              report.
            </p>
          </div>
          <div className="query-list">
            {queryExamples.map((example, index) => (
              <article className="query-card" key={example.title}>
                <div className="query-card-header">
                  <div>
                    <h3>{example.title}</h3>
                    <p>{example.description}</p>
                  </div>
                  <button
                    className="copy-sql"
                    onClick={() => copySql(index, example.sql)}
                    aria-label={`Copy ${example.title}`}
                  >
                    {copied === index ? (
                      <Check size={14} />
                    ) : (
                      <Copy size={14} />
                    )}
                    {copied === index ? "Copied" : "Copy SQL"}
                  </button>
                </div>
                <pre>
                  <code>{example.sql}</code>
                </pre>
              </article>
            ))}
          </div>
        </section>
        <section className="db-journey">
          <div className="eyebrow">THE BOOKING, IN FOUR STEPS</div>
          <div className="journey-steps">
            <div>
              <span>01</span>
              <strong>Choose a showtime</strong>
              <small>movies → showtimes → auditoriums</small>
            </div>
            <ArrowRight />
            <div>
              <span>02</span>
              <strong>Select your seats</strong>
              <small>seat map − reserved seats</small>
            </div>
            <ArrowRight />
            <div>
              <span>03</span>
              <strong>Commit together</strong>
              <small>customer + booking + seats</small>
            </div>
            <ArrowRight />
            <div>
              <span>04</span>
              <strong>Keep the reference</strong>
              <small>booking.reference → lookup</small>
            </div>
          </div>
        </section>
        <section className="db-endcap">
          <span className="endcap-ticket">
            <Ticket size={21} />
          </span>
          <div>
            <div className="eyebrow">THAT'S THE WHOLE PICTURE</div>
            <h2>
              Now go enjoy <em>the show.</em>
            </h2>
          </div>
          <Link href="/" className="primary-cta">
            Back to ReelBook <ArrowRight size={15} />
          </Link>
        </section>
      </main>
      <footer className="footer db-footer">
        <Link href="/" className="brand footer-brand">
          <span className="brand-mark">
            <Ticket size={17} />
          </span>
          <span>
            reelbook<span className="brand-dot">.</span>
          </span>
        </Link>
        <span>RELATIONAL DATA, HUMAN-SIZED.</span>
        <span>MADE FOR PEOPLE WHO LOVE A GOOD STORY.</span>
      </footer>
    </div>
  );
}
