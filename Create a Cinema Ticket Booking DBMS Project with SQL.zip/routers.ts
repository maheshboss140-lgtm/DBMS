import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  createBooking,
  getBookingByReference,
  getCatalog,
  getShowtimeAvailability,
  getShowtimes,
} from "./cinemaDb";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  cinema: router({
    catalog: publicProcedure.query(() => getCatalog()),
    showtimes: publicProcedure
      .input(
        z.object({
          date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          cinemaId: z.number().int().positive().optional(),
        })
      )
      .query(({ input }) => getShowtimes(input.date, input.cinemaId)),
    availability: publicProcedure
      .input(z.object({ showtimeId: z.number().int().positive() }))
      .query(({ input }) => getShowtimeAvailability(input.showtimeId)),
    book: publicProcedure
      .input(
        z.object({
          showtimeId: z.number().int().positive(),
          seatIds: z.array(z.number().int().positive()).min(1).max(8),
          customer: z.object({
            name: z.string().trim().min(2).max(160),
            email: z.string().trim().email().max(254),
            phone: z.string().trim().min(7).max(32),
          }),
        })
      )
      .mutation(({ input }) => createBooking(input)),
    bookingByReference: publicProcedure
      .input(z.object({ reference: z.string().trim().min(6).max(20) }))
      .query(({ input }) => getBookingByReference(input.reference)),
  }),
});

export type AppRouter = typeof appRouter;
