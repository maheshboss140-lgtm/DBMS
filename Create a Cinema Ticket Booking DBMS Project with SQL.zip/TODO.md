# TODO — ReelBook

- [x] **Cinema and movie discovery:** The website must let customers browse cinemas with essential venue details and available screenings; browse movies with posters, summaries, genres, durations, ratings, and release information; and view movie showtimes by cinema and date.
- [x] **Showtime and seat selection:** Customers must be able to open a showtime’s auditorium layout and see seats marked as available, selected, or booked; select seats with a live ticket count and booking total summary.
- [x] **Booking and confirmation:** Customers must be able to complete a ticket booking using customer details and receive a unique booking reference; view a booking confirmation and retrieve booking details by booking reference.
- [x] **Relational booking integrity:** Prevent duplicate seat reservations for the same showtime through database constraints and transactional booking logic.
- [x] **Academic database design:** Provide an academic database-design page with an ER diagram, relational schema, table descriptions, primary and foreign keys, and example SQL queries.
- [x] **SQL and application implementation:** Deliver the cinema ticket booking project using SQL and other languages, with a functioning customer booking flow connected to its relational database design.
