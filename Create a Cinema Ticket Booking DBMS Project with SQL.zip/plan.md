# ReelBook — Implementation Plan

## Product and architecture

ReelBook is an academic cinema-ticket booking website that demonstrates a complete customer flow and an understandable relational database design. It uses the initialized React 19 + TypeScript frontend and Express/tRPC backend, Drizzle ORM with the managed MySQL database, and Lucide icons already installed. The frontend browses cinemas, films, and dated showtimes; renders an auditorium seat map; lets a customer select available seats and review a live total; submits customer details; and displays a retrievable booking confirmation with a unique reference. The SQL-backed model covers cinemas, auditoriums, seats, movies, showtimes, customers, bookings, and booking-seat relationships. Database constraints and transactional booking logic prevent duplicate reservations for the same showtime. A dedicated database-design view explains the ER model, relational schema, keys, tables, and useful SQL queries.

The client uses the existing Wouter routing and tRPC React Query client. The backend exposes read procedures for catalog, screenings and availability, plus a transactional booking procedure and lookup by booking reference. Drizzle schema changes and additive SQL migrations live in `drizzle/`. Demo catalog rows are inserted idempotently so the project opens with useful content; bookings persist in MySQL. The supplied starter's existing users/auth table is preserved. No payment processing or sign-in is in the requested project scope.

## Project structure

- `client/src/pages/Home.tsx` and focused components under `client/src/components/`: cinema browsing, featured-film hero, poster shelf, showtimes, interactive seat selection, customer details, and booking entry.
- `client/src/pages/BookingConfirmation.tsx`: confirmation card and reference retrieval route.
- `client/src/pages/DatabaseDesign.tsx`: ER diagram, relational schema, and copyable SQL examples.
- `client/src/index.css`: the app's own responsive visual system, layout, and interaction states.
- `/manus-storage/async-images/...`: original generated hero and film-poster artwork served from managed project storage.
- `client/src/App.tsx` and `client/public/manus-routes.json`: page routing and the required synchronized route manifest.
- `drizzle/schema.ts`, `drizzle/relations.ts`, and the generated additive cinema migration: relational entities and constraints.
- `server/cinemaDb.ts` and `server/routers.ts`: catalog reads, availability reads, demo catalog initialization, transactional booking and reference lookup, exposed through tRPC.
- `plan.md` and `TODO.md`: product decisions and outcome status.

## Design direction

Style possibilities: **Midnight repertory marquee** (0.07), **Paper ticket editorial** (0.04), **Neon multiplex arcade** (0.06). Selected: **Paper ticket editorial**.

- **Design Movement:** Contemporary cinema-programme editorial, drawing on printed repertory guides and tactile ticket stock rather than a generic booking dashboard.
- **Core Principles:** Make film artwork the emotional entry point; keep discovery and booking controls legible and immediate; reveal database learning material without interrupting the customer journey; use generous whitespace and restrained ornamental details.
- **Color Philosophy:** Warm ivory and pale ticket-stock neutrals establish a printed-programme atmosphere. Near-black ink anchors text, while a distinctive tomato-red is reserved for booking actions, selected seats, and tiny marquee accents. Deep forest green signals availability and success; muted grey communicates booked or inactive states.
- **Layout Paradigm:** An asymmetrical, magazine-like home page with a narrow persistent navigation rail, an oversized featured-film spread, a horizontally browsable poster shelf, and a showtime-first booking surface. A responsive booking drawer contains the selected film/showtime seat map; the learning section uses stacked relation cards and a readable schema diagram.
- **Signature Elements:** Perforation notches and dotted ticket rules; large condensed film titles paired with tiny uppercase metadata; small ticket-stub number motifs for references and database entities.
- **Interaction Philosophy:** Browsing stays low-friction. Showtime and seat choices visibly update booking context and price. Seat states always have a text/key explanation as well as color; confirmation presents a clear reference that can be looked up again.
- **Animation:** Brief, gentle fade/slide when changing film or opening booking; subtle seat selection pop and a short confirmation flourish. Respect `prefers-reduced-motion`; never use continuous decoration or block control during animation.
- **Typography System:** DM Sans for readable interface text, paired with DM Serif Display for editorial film and section headlines. Use compact IBM Plex Mono for seat labels, times, and ticket/reference metadata.
- **Brand Essence:** A friendly cinema-booking experience that doubles as a clear, presentable DBMS project; **editorial, dependable, curious**.
- **Brand Voice:** Precise, film-loving, and student-demo friendly. Example lines: “Find your next favourite.” “Pick a show. Claim your seats.”
- **Wordmark & Logo:** A custom wordmark treatment with a small ticket stub whose perforated edge forms a reel frame; use the CSS-drawn mark and a matching original ticket-stub SVG favicon.
- **Signature Brand Color:** Marquee tomato, `#E44732`.

## Material constraints

The managed database is shared by development and published runtime, so changes are additive and seeded rows must be idempotent. No destructive migration or reset is planned. Keep the code in the supplied stack, avoid adding unnecessary dependencies, and preserve the starter login/user schema. Use relative URLs in browser code and keep `/manus-routes.json` aligned with the actual page routes.
